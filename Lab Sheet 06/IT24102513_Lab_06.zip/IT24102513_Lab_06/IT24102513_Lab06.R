setwd("C:/Users/mathu/Desktop/IT24102513_Lab_06")
##Exercise
##Question1

##(i)Distribution of X
#Binomial distribution

##(ii)Probability that at least 47 students passed the test
#P(X>=47)
1- pbinom(46, 50, 0.85, lower.tail = TRUE)

#Question2

##(i)Random variable (X) for the problem
#X = Number of calls received in one hour

##(ii)Distribution of X
#Poisson distribution

##(iii)probability that exactly 15 calls are received in an hour
dpois(15,12)