## Q1
##Import the dataset
setwd("C:/Users/IT24102513/Desktop/IT24102513")

Delivery_Times<-read.table("Exercise - Lab 05.txt",header=TRUE)

fix(Delivery_Times)

str(Delivery_Times)

colnames(Delivery_Times)

## Q2
##histogram for deliver times using nine class intervals where the lower limit is 20 and upper limit is 70

hist(Delivery_Times$Delivery_Time_.minutes, right=FALSE,main =" Histogram for deliver times",
     breaks<-seq(20,70,length.out = 10),
     xlab="Delivery_Times",ylab="Frequency",col="blue",labels = FALSE)

##Q3
##Comment on the shape of the distribution

## Q4
## cumulative frequency polygon (ogive)
Delivery_Times_freq<-hist(Delivery_Times$Delivery_Time_.minutes,breaks = breaks, 
     right = FALSE, plot = FALSE)

cum.freq<- cumsum(Delivery_Times_freq$counts)

plot(Delivery_Times_freq$mids, cum.freq, type = "o",
     main = "Ogive (Cumulative Frequency Polygon of Delivery Times)",
     xlab = "Delivery Time", ylab = "Cumulative Frequency",pch =16,col="red")


